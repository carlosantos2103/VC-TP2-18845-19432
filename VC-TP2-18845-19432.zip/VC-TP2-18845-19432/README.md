# VC-TP2-18845-19432
Trabalho Prático Visão de Computador
