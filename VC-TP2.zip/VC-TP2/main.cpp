//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//           INSTITUTO POLITECNICO DO CAVADO E DO AVE
//                          2020/2021
//             ENGENHARIA DE SISTEMAS INFORMATICOS
//                 VISAO POR COMPUTADOR - TP2
//
//                [  JOAO AZEVEDO   - 18845  ]
//                [  CARLOS SANTOS  - 19432  ]
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#include <iostream>
#include <string>
#include <opencv2\opencv.hpp>
#include <opencv2\core.hpp>
#include <opencv2\highgui.hpp>
#include <opencv2\videoio.hpp>
using namespace std;

extern "C" {
	#include "vc.h"
}


int main(void) {
	// V�deo
	char videofile[20] = "video.avi";
	cv::VideoCapture capture;
	struct
	{
		int width, height;
		int ntotalframes;
		int fps;
		int nframe;
	} video;
	// Outros
	std::string str;
	int key = 0;

	capture.open(0, cv::CAP_DSHOW);

	/* Verifica se foi poss�vel abrir o ficheiro de v�deo */
	if (!capture.isOpened())
	{
		std::cerr << "Erro ao abrir o v�deo!\n";
		return 1;
	}

	/* N�mero total de frames no v�deo */
	video.ntotalframes = (int)capture.get(cv::CAP_PROP_FRAME_COUNT);
	/* Frame rate do v�deo */
	video.fps = (int)capture.get(cv::CAP_PROP_FPS);
	/* Resolu��o do v�deo */
	video.width = (int)capture.get(cv::CAP_PROP_FRAME_WIDTH);
	video.height = (int)capture.get(cv::CAP_PROP_FRAME_HEIGHT);

	/* Cria uma janela para exibir o v�deo */
	cv::namedWindow("VC - Video", cv::WINDOW_AUTOSIZE);

	/* Declara��o de vari�veis*/
	IVC* image[4];
	image[0] = vc_image_new(video.width, video.height, 3, 255);
	image[1] = vc_image_new(video.width, video.height, 3, 255);
	image[2] = vc_image_new(video.width, video.height, 1, 255);
	image[3] = vc_image_new(video.width, video.height, 1, 255);
	int labels, i, j;
	OVC* blobs;
	int aux, xCenter;
	float percent, percent2, percent3, percent4;
	OVC mainBlob, auxBlob;
	string sinal;

	cv::Mat frame;
	cv::Mat frame2;
	while (key != 'q') {
		/* Leitura de uma frame do v�deo */
		capture.read(frame);
		/* Verifica se conseguiu ler a frame */
		if (frame.empty()) break;
		/* N�mero da frame a processar */
		video.nframe = (int)capture.get(cv::CAP_PROP_POS_FRAMES) / 2;

		// Copia dados de imagem da estrutura cv::Mat para uma estrutura IVC
		memcpy(image[0]->data, frame.data, video.width * video.height * 3);

		// Converter de BGR para RGB 
		vc_convert_bgr_to_rgb(image[0], image[1]);
		// Converter uma imagem do espa�o RBG para HSV
		vc_rgb_to_hsv(image[1], image[0]);
		// Converte uma imagem HSV para uma imagem binaria
		vc_hsv_segmentation(image[0], image[2], 180, 260, 50, 100, 50, 100);
		// Efetua uma Dilatacao apos uma erosao
		vc_binary_open(image[2], image[3], 1, 5);

		// Calculo do numero de blobs
		blobs = vc_binary_blob_labelling(image[3], image[2], &labels);
		// Calculo da area, centro de massa ...
		vc_binary_blob_info(image[2], blobs, labels);

		// Inicializacaso das variaveis 
		mainBlob.area = 0;
		sinal = "";

		// Caso nao exista blobs
		if (blobs != NULL) {

			// Ordena��o dos blobs por ordem decrescente tendo em conta a sua �rea
			for (i = 0; i < labels - 1; i++)
			{
				for (j = i + 1; j < labels; j++)
				{
					if (blobs[i].area < blobs[j].area)
					{
						auxBlob = blobs[i];
						blobs[i] = blobs[j];
						blobs[j] = auxBlob;
					}
				}
			}

			//VERIFICA QUE E UM OBJETO GRANDE E � UM QUADRADO
			if (blobs[0].area > 6000 && abs(blobs[0].width - blobs[0].height) < 15) {
				mainBlob = blobs[0];
				// Calculo da percentagem do blob sob a area maior
				percent = mainBlob.perimeter * 100 / (float)mainBlob.area;
				// Caso esteja compreendido entre estes valores e uma seta
				if (percent >= 3.7 && percent <= 5.0) {	
					xCenter = mainBlob.x + mainBlob.width / 2;
					// Se o centro de massa estiver mais para a direita isto supeior ao centro de massa da imagem total
					if (mainBlob.xc > xCenter)
						sinal = "Obrigatorio virar a esquerda";
					// Se o centro de massa estiver mais para a esquerda isto inferior ao centro de massa da imagem total
					else if (mainBlob.xc < xCenter)
						sinal = "Obrigatorio virar a direita";
				} // Caso seja superior a 5.1 sera obrigatoriamente um carro ou uma auto-estrada
				else if (percent > 5.1) { 
					// Se o numero de objetos for superior for a 3 sera em principio um carro
					if (labels > 3) {
						percent2 = blobs[1].area * 100 / (float)mainBlob.area;
						percent3 = blobs[2].area * 100 / (float)mainBlob.area;
						percent4 = blobs[3].area * 100 / (float)mainBlob.area;
						// Confirmacao se sera um carro caso esteja compreendido entre estes valores
						if (percent2 >= 13.0 && percent2 < 17.0 && percent3 >= 0.8 && percent3 < 2.7 && percent4 >= 0.8 && percent4 < 2.7) {
							sinal = "Via de automoveis e motociclos";
						} // Caso nao seja nenhum dos valores anteriores sera uma auto-estrada
						else sinal = "Auto-Estrada";
					}
					else // Caso tenha menos de 4 objetos
						sinal = "Auto-Estrada";
				}
			}
		}
		
		// Caso nao reconheca nenhum blob com a cor azul, sera porque e vermelho a cor do mesmo
		if (mainBlob.area == 0) {
			// Libertar Memoria
			free(blobs);
			// Converte uma imagem HSV para uma imagem binaria
			vc_hsv_red_segmentation(image[0], image[2], 346, 9, 70, 100, 80, 100);
			// Efetua uma Dilatacao apos uma erosao
			vc_binary_open(image[2], image[3], 3, 7);

			// Calculo do numero de blobs
			blobs = vc_binary_blob_labelling(image[3], image[2], &labels);
			// Calculo da area, centro de massa ...
			vc_binary_blob_info(image[2], blobs, labels);

			// Caso nao exista blobs
			if (blobs != NULL) {

				// Ordena��o dos blobs por ordem decrescente tendo em conta a sua �rea
				for (i = 0; i < labels - 1; i++)
				{
					for (j = i + 1; j < labels; j++)
					{
						if (blobs[i].area < blobs[j].area)
						{
							auxBlob = blobs[i];
							blobs[i] = blobs[j];
							blobs[j] = auxBlob;
						}
					}
				}
				//VERIFICA QUE E UM OBJETO GRANDE E � UM QUADRADO
				if (blobs[0].area > 6000 && abs(blobs[0].width - blobs[0].height) < 15) {
					mainBlob = blobs[0];
					// Calculo da percentagem do blob sob a area maior
					percent = mainBlob.perimeter * 100 / (float)mainBlob.area;
					// Caso esteja compreendido entre estes valores sera o sinal stop
					if (percent >= 6.8 && percent <= 10.0) {
						sinal = "STOP";
					} 
					// Caso esteja compreendido entre estes valores sera o sinal proibido
					else if (percent > 3.5) {
						sinal = "PROIBIDO";
					}
				}
			}
		}

		// Libertar Memoria
		free(blobs);
		memcpy(image[0]->data, frame.data, video.width * video.height * 3);
		if (sinal != "") {
			// Alocar Memoria
			blobs = (OVC*)calloc((1), sizeof(OVC));
			blobs[0] = mainBlob;
			// Desenhar bounding boxes 
			vc_draw_bouding_box(image[2], image[0], blobs, 1);
			// Desenhar centro de massa
			vc_draw_center_mass(image[2], image[0], blobs, 1);
			free(blobs);
		}

		// Copia dados de imagem da estrutura IVC para uma estrutura cv::Mat
		memcpy(frame.data, image[0]->data, video.width* video.height * 3);
		if (sinal != "") {
			str = std::string("SINAL: ").append(sinal);
			cv::putText(frame, str, cv::Point(20, 25), cv::FONT_HERSHEY_SIMPLEX, 1.0, cv::Scalar(0, 0, 0), 2);
			cv::putText(frame, str, cv::Point(20, 25), cv::FONT_HERSHEY_SIMPLEX, 1.0, cv::Scalar(255, 255, 255), 1);
		}
		cv::imshow("VC - Video", frame);
		
		/* Sai da aplica��o, se o utilizador premir a tecla 'q' */
		key = cv::waitKey(1);
	}

	// Libertar Memoria
	vc_image_free(image[0]);
	vc_image_free(image[1]);
	vc_image_free(image[2]);
	vc_image_free(image[3]);
	/* Fecha a janela */
	cv::destroyWindow("VC - Video");

	/* Fecha o ficheiro de v�deo */
	capture.release();

	return 0;
}